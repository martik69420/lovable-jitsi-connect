-- Add class column to profiles table
ALTER TABLE public.profiles ADD COLUMN class text;